package joecohen;

import org.jfree.ui.RefineryUtilities;

/**
 * Observer Design Pattern Demo
 * 
 * @author Joseph Paul Cohen 2010
 * @version 1
 */
public class Runner {

	public static void main(String[] args) {
		
		/*
		 * We create a subject and something to control it
		 */
		Subject subject = new Subject();
		SubjectController controller = new SubjectController(subject);
		RefineryUtilities.positionFrameOnScreen(controller, .50, .75);
		
		/*
		 * We create an Observer that displays a bar graph
		 */
		BarChart barGraph = new BarChart();
		subject.addObserver(barGraph);
		RefineryUtilities.positionFrameOnScreen(barGraph, .15, .25);
		
		/*
		 * We create an Observer that displays a pie graph
		 */
		PieChart pieGraph = new PieChart();
		subject.addObserver(pieGraph);
		RefineryUtilities.positionFrameOnScreen(pieGraph, .85, .25);

	}

}
