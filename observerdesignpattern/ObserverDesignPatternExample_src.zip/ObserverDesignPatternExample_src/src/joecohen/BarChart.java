package joecohen;

import java.awt.Dimension;
import java.awt.Toolkit;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;

/**
 * Observer Design Pattern Demo
 * 
 * @author Joseph Paul Cohen 2010
 * @version 1
 */
public class BarChart extends ApplicationFrame implements SubjectObserver{
	private static final long serialVersionUID = 1L;

	private String rowA = "A";
	private String rowB = "B";
	private String rowC = "C";
	
	private Integer A = 4;
	private Integer B = 5;
	private Integer C = 3;
	private DefaultCategoryDataset dataset = createDataset();
	
	
    public BarChart() {
        super("BarChart");
        ChartPanel chartPanel = new ChartPanel(createChart());
        chartPanel.setMouseWheelEnabled(true);
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
        chartPanel.setPreferredSize(new Dimension(screensize.width/3, screensize.height/3));
        setContentPane(chartPanel);
        this.pack();
        this.setVisible(true);
    }

    private DefaultCategoryDataset createDataset() {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(A, rowA, "");
        dataset.addValue(B, rowB, "");
        dataset.addValue(C, rowC, "");
        return dataset;
    }

    private JFreeChart createChart() {

        JFreeChart chart = ChartFactory.createBarChart3D(
            null,       				// chart title
            null,               	 	// domain axis label
            "Value",                  	// range axis label
            dataset,                  	// data
            PlotOrientation.VERTICAL, 	// orientation
            true,                     	// include legend
            true,                     	// tooltips?
            false                     	// URLs?
        );
        return chart;
    }

	public void notifyAChanged(Integer newValue) {

		dataset.setValue(newValue, rowA, "");
	}

	public void notifyBChanged(Integer newValue) {

		dataset.setValue(newValue, rowB, "");
	}

	public void notifyCChanged(Integer newValue) {

		dataset.setValue(newValue, rowC, "");		
	}
    
    
}
