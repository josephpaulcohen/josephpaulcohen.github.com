package joecohen;

import java.awt.GridLayout;
import javax.swing.JSlider;

import javax.swing.JFrame;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Observer Design Pattern Demo
 * 
 * @author Joseph Paul Cohen 2010
 * @version 1
 */
public class SubjectController extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private JSlider jSliderA;
	private JSlider jSliderB;
	private JSlider jSliderC;
	
	public SubjectController(final Subject subject) {
		super("SubjectController");
		getContentPane().setLayout(new GridLayout(3, 1));
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		jSliderA = new JSlider(0,100,subject.getA());
		getContentPane().add(jSliderA);
		jSliderA.addChangeListener(new ChangeListener() {
			
			public void stateChanged(ChangeEvent e) {
				subject.setA(jSliderA.getValue());
				
			}
		});
		
		jSliderB = new JSlider(0,100,subject.getB());
		getContentPane().add(jSliderB);
		jSliderB.addChangeListener(new ChangeListener() {
			
			public void stateChanged(ChangeEvent e) {
				subject.setB(jSliderB.getValue());
				
			}
		});
		
		jSliderC = new JSlider(0,100,subject.getC());
		jSliderC.setMajorTickSpacing(10);
		jSliderC.setPaintLabels(true);
		getContentPane().add(jSliderC);
		jSliderC.addChangeListener(new ChangeListener() {
			
			public void stateChanged(ChangeEvent e) {
				subject.setC(jSliderC.getValue());
				
			}
		});
		
		pack();
		setSize(500, 200);
		setVisible(true);
	}
}
