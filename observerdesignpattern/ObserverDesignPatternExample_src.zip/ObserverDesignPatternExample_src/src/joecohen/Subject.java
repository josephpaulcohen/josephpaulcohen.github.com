package joecohen;

import java.util.ArrayList;
import java.util.List;

/**
 * Observer Design Pattern Demo
 * 
 * @author Joseph Paul Cohen 2010
 * @version 1
 */
public class Subject {

	private List<SubjectObserver> observers = new ArrayList<SubjectObserver>();
	
	/**
	 * This will add an observer to this Subject
	 * 
	 * @param observer
	 * @return
	 */
	public boolean addObserver( SubjectObserver observer){
		
		return observers.add(observer);
	}

	private Integer A = 4;
	private Integer B = 5;
	private Integer C = 3;
	
	public void setA(Integer a) {
		
		A = a;
		for (SubjectObserver observer : observers)
			observer.notifyAChanged(a);
	}
	public Integer getA() {
		
		return A;
	}
	public void setB(Integer b) {
		
		B = b;
		for (SubjectObserver observer : observers)
			observer.notifyBChanged(b);
	}
	public Integer getB() {
		
		return B;
	}
	public void setC(Integer c) {

		C = c;
		for (SubjectObserver observer : observers)
			observer.notifyCChanged(c);
	}
	public Integer getC() {
		
		return C;
	}
	
	
	
}
