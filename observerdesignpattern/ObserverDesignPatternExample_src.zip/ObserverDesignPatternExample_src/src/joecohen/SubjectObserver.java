package joecohen;

/**
 * Observer Design Pattern Demo
 * 
 * @author Joseph Paul Cohen 2010
 * @version 1
 */
public interface SubjectObserver {

	/**
	 * This method is called when the value of A changes
	 * 
	 * @param newValue
	 */
	public void notifyAChanged(Integer newValue);
	
	/**
	 * This method is called when the value of C changes
	 * 
	 * @param newValue
	 */
	public void notifyBChanged(Integer newValue);
	
	/**
	 * This method is called when the value of C changes
	 * 
	 * @param newValue
	 */
	public void notifyCChanged(Integer newValue);
}
