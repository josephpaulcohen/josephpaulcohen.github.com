package joecohen;

import java.awt.Dimension;
import java.awt.Toolkit;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;

/**
 * Observer Design Pattern Demo
 * 
 * @author Joseph Paul Cohen 2010
 * @version 1
 */
public class PieChart extends ApplicationFrame implements SubjectObserver{
	private static final long serialVersionUID = 1L;

	private String rowA = "A";
	private String rowB = "B";
	private String rowC = "C";
	
	private Integer A = 4;
	private Integer B = 5;
	private Integer C = 3;
	private PieDataset dataset = createDataset();
	PiePlot plot;
	
	
    public PieChart() {
        super("PieChart");
        ChartPanel chartPanel = new ChartPanel(createChart());
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
        chartPanel.setPreferredSize(new Dimension(screensize.width/3, screensize.height/3));
        setContentPane(chartPanel);
        this.pack();
        this.setVisible(true);
    }

    private PieDataset createDataset() {
        
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue(rowA, new Double(A));
        dataset.setValue(rowB, new Double(B));
        dataset.setValue(rowC, new Double(C));
        return dataset;

    }

    private JFreeChart createChart() {

        JFreeChart chart = ChartFactory.createPieChart(
                null,
                dataset,
                true,
                true,
                false
            );

            plot = (PiePlot) chart.getPlot();
            return chart;
    }

	public void notifyAChanged(Integer newValue) {
		
		A = newValue;
        plot.setDataset(createDataset());
	}

	public void notifyBChanged(Integer newValue) {

		B = newValue;
        plot.setDataset(createDataset());
	}

	public void notifyCChanged(Integer newValue) {

		C = newValue;
        plot.setDataset(createDataset());	
	}
    
    
}
